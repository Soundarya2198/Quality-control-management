const request = require("supertest")
const app = require('../src/app.js')
const jwt = require("jsonwebtoken")
require("dotenv").config()


jest.mock("../models", () => ({
    Inspection: {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
    },
    User: {}
}));

const { Inspection } = require("../models");

describe("POST api/inspections/create", () => {
    let token;
    beforeEach(() => {
        token = jwt.sign(
        {
            id: 1,
            email: "admin@test.com",
            role: 1
        },
        process.env.JWT_SECRET,
        {
            expiresIn: '1h'
        })
    });
    afterEach(() => {
        jest.clearAllMocks()
    });
  
    test("Inspection create success", async() => {

    Inspection.create.mockResolvedValue({
        id: 1,
        product_name: "test",
        inspector_id: 1,
        inspection_date: "2020-01-01",
        status: 2
    })
    const response = await request(app)
            .post("/api/inspections/create")
            .set("Authorization", `Bearer ${token}`)
            .send({
                product_name : "test",
                inspector_id : 1,
                inspection_date: "2020-01-01",
                status: 2
            })

        expect(response.statusCode).toBe(201)
        expect(response.body.success).toBe(true)
        expect(response.body.message).toBe("Inspection created succesfully")
        expect(Inspection.create).toHaveBeenCalledTimes(1);

        expect(Inspection.create).toHaveBeenCalledWith({
            product_name : "test",
            inspector_id : 1,
            inspection_date: "2020-01-01",
            status: 2
        });
    });

    test("Inspection all fields required", async() => {
        const response = await request(app)
            .post("/api/inspections/create")
            .set("Authorization", `Bearer ${token}`)
            .send({
            product_name: ""
        })
        
        expect(response.statusCode).toBe(400)
        expect(response.body.success).toBe(false)
        expect(response.body.message).toBe("All fields are required")
    });
})

describe("GET Get All Inspections", () => {
    let token;
    beforeEach(() => {
       token = jwt.sign(
        {
            id: 1,
            email: "admin@test.com",
            role: 1
        },
        process.env.JWT_SECRET,
        {
            expiresIn: '1h'
        })
    })
    afterEach(() => {
        jest.clearAllMocks()
    })

    test("All inspections sucess", async () => {
        Inspection.findAll.mockResolvedValue([
             {
                id: 1,
                product_name: "Product 1",
                inspector_id: 1,
                inspection_date: "2020-01-01",
                status: 2
            },
            {
                id: 2,
                product_name: "Product 2",
                inspector_id: 2,
                inspection_date: "2020-01-02",
                status: 1
            }
        ]);
    const response = await request(app)
        .get("/api/inspections/")
        .set("Authorization", `Bearer ${token}`)
        
    expect(response.statusCode).toBe(200)
    expect(response.body.success).toBe(true)
    expect(response.body.message).toBe("Data retrived successfully")
    expect(response.body.data).toBeDefined()
    expect(response.body.data).toHaveLength(2)
    })
})

describe("DELETE Delete inspections", () => {
    let token;
    afterEach(() => {
        jest.clearAllMocks()
    });
    beforeEach(()=> {
       token = jwt.sign(
        {
            id: 1,
            email: "admin@test.com",
            role: 1
        },
        process.env.JWT_SECRET,
        {
            expiresIn: '1h'
        })
    });
   

    test("Delete Sucessfull", async () => {
        const mockInspection = {
            id: 1,
            destroy: jest.fn()
        }

        Inspection.findOne.mockResolvedValue(mockInspection);
        mockInspection.destroy.mockResolvedValue()

        const response = await request(app)
        .delete("/api/inspections/delete/1")
        .set("Authorization", `Bearer ${token}`)

        expect(response.statusCode).toBe(200)
        expect(response.body.success).toBe(true)
        expect(response.body.message).toBe("Inspection deleted Succesfully")
    })

    test("Delete id not found", async () => {
       
        Inspection.findOne.mockResolvedValue(null)

        const response = await request(app)
        .delete("/api/inspections/delete/2")
        .set("Authorization", `Bearer ${token}`)

        expect(response.statusCode).toBe(400)
        expect(response.body.success).toBe(false)
        expect(response.body.message).toBe("Inspection not found")
    })
})
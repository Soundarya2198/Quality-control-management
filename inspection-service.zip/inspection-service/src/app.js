const express = require("express")
const app = express()
const inspectionRouter = require("../src/routes/inspection.router.js")
const cors = require("cors")
const morgan = require("morgan")
const errorHandler = require("../src/middlewares/error.middleware.js")

app.use(cors())
app.use(express.json())
app.use(morgan("dev"))
app.use(errorHandler)
app.use("/api/inspections", inspectionRouter)

module.exports = app;
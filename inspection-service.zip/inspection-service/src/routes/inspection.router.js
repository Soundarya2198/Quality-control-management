const express = require("express");
const router = express.Router()
const {createInspection, getAllInspections, getInspectionById, updateInspectionById, updateInspectionStatus, deleteInspection} = require("../controllers/inspection.controller.js")
const {verifyToken} = require("../middlewares/auth.middleware.js")
const {authorize} = require("../middlewares/authorize.middleware.js")
const ROLES = require("../../config/roles.js")

router.post("/create", verifyToken, authorize(ROLES.MANAGER, ROLES.ADMIN),  createInspection)
router.get("/", verifyToken, authorize(ROLES.MANAGER, ROLES.ADMIN, ROLES.INSPECTOR),  getAllInspections)
router.get("/:id", verifyToken, authorize(ROLES.MANAGER, ROLES.ADMIN),  getInspectionById)
router.put("/update/:id", verifyToken, authorize(ROLES.MANAGER, ROLES.INSPECTOR, ROLES.ADMIN),  updateInspectionById)
router.put("/status/:id", verifyToken, authorize(ROLES.INSPECTOR, ROLES.ADMIN),  updateInspectionStatus)
router.delete("/delete/:id", verifyToken, authorize(ROLES.INSPECTOR, ROLES.MANAGER, ROLES.ADMIN),  deleteInspection)

module.exports = router;

const {Inspection, User} = require("../../models");
const logger = require("../utils/logger.js")

const createInspection = async (req, res) => {
    try{
        const {product_name, inspector_id, inspection_date, status} = req.body;
        if(!product_name || !inspection_date || !status || !inspector_id){
            return res.status(400).json({
                success: false,
                message: "All fields are required"
            })
        }
        const inspection = await Inspection.create({
            product_name,
            inspector_id,
            inspection_date,
            status
        });
        
        logger.info("Inspection created")
        return res.status(201).json({
            success: true,
            message: "Inspection created succesfully"
        })
    }catch(e){
        logger.error(`Inspection creation Error: ${e.message}`)
        return res.status(500).json({
            success: false,
            message: "Internam Server error"
        })
    }
}

const getAllInspections = async (req, res) => {
try{
   const page = req.query.page || 1;
   const limit = req.query.limit  || 10;
   const offset = (page-1) * limit;

   const inspections = await Inspection.findAll({
    include: [
      {
        model: User,
        as: "inspector",
        attributes: ["id", "name", "email"]
      }
    ],
    limit,
    offset,
    order: [["created_at", "DESC"]]
   })
   return res.status(200).json({
    success: true,
    message: "Data retrived successfully",
    data : inspections
   })
}catch(e){
    logger.error(`Inspection Error: ${e.message}`)
    return res.status(500).json({
        message: "Internal server error",
        success: false
    })
}
}

const getInspectionById = async (req, res) => {
   try{
    const id = req.params.id;
    const inspection = await Inspection.findOne({
        where: {
            id: id
        }
    })
    if(!inspection){
        logger.warn(`Inspection not found ${id}`)
        return res.status(404).json({
            success: false,
            message: "Inspection not found"
        })
    }
    return res.status(200).json({
        success: true,
        message: `User id ${id} reterived successfully`,
        data: inspection
    })
}catch(e){
    console.log(e)
    logger.error(`Inspection Error: ${e.message}`)
    return res.status(500).json({
        message: "Internal Server error",
        success: false
    })
}
}

const updateInspectionById = async (req, res) => {
    try{
    const id = req.params.id;
    const {product_name, inspector_id, status, inspection_date} = req.body;

    if(!product_name || !inspection_date || !status || !inspector_id){
            return res.status(400).json({
                success: false,
                message: "All fields are required"
            })
    }

    const inspection = await Inspection.findOne({
        where: {
            id: id
        }
    })
    if(!inspection){
        logger.warn(`Inspection not found ${id}`)
        return status(404).json({
            success: false,
            message: "Inspection Not found"
        })
    }

    await inspection.update({
        product_name,
        inspection_date,
        inspector_id,
        status
    })
    
    logger.info(`Inspection Updated ${id}`)
    return res.status(200).json({
        success: true,
        message: "Inspector Updated Successfully"
    })
}catch(e){
    logger.error(`Inspection error: ${e.message}`)
    return res.status(500).json({
        message: "Internal Server error",
        success: false
    })
}
    
}

const updateInspectionStatus = async (req, res) => {
  try{
     const id = req.params.id;
     const status = req.body.status;
     if(!status || ![1,2,3,4].includes(status)){
        logger.warn(`Status is invalid ${status}`)
        return res.status(400).json({
            success: false,
            message: "Status is invalid"
        })
     }
     const inspection = await Inspection.findOne({
        where: {
            id: id
        }
     })
     if(!inspection){
        logger.warn(`Inspection not found ${id}`)
        return res.status(404).json({
            success: false,
            message: "Inspection not found"
        })
     }

     inspection.status = status;
     await inspection.save();
     logger.info(`Inspection status updated ${status} ${id}`)
     return res.status(200).json({
        success: true,
        message: "Inspection Status Updated Succesfully"
     })
  }catch(e){
    logger.error(`Inspection Error: ${e.message}`)
    return res.status(500).json({
        success: false,
        message: "Internal server error"
    })
  }
}

const deleteInspection = async(req, res) => {
    try{
        const id = req.params.id;
        const inspection = await Inspection.findOne({
            where: {
                id: id
            }
        })
        if(!inspection){
            logger.warn(`Inspection not found ${id}`)
            return res.status(400).json({
                success: false,
                message: "Inspection not found"
            })
        }

        await inspection.destroy();
        logger.info(`Inspection deleted ${id}`)
        return res.status(200).json({
            success: true,
            message: "Inspection deleted Succesfully"
        })

    }catch(e){
        logger.error(`Inspection error: ${e.message}`)
        return res.status(500).json({
            success: false,
            message: "Internal server error"
        })
    }
}

module.exports = {
    createInspection,
    getAllInspections,
    getInspectionById,
    updateInspectionById,
    updateInspectionStatus,
    deleteInspection
}
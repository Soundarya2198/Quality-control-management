const ROLES = {
    ADMIN : 1,
    INSPECTOR: 2,
    MANAGER: 3
}

module.exports = ROLES;
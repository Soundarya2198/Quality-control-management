module.exports = (sequelize, DataTypes) => {
   const Inspection = sequelize.define(
    "Inspection",
    {
        id: {
            type: DataTypes.BIGINT,
            primaryKey: true,
            autoIncrement: true
        },
        product_name:{
            type: DataTypes.STRING(100),
            allowNull: false
        },
        inspection_date:{
            type: DataTypes.DATE,
            allowNull: false
        },
        inspector_id: {
            type: DataTypes.BIGINT,
            allowNull: false
        },
        status: {
            type: DataTypes.SMALLINT,
            allowNull: false
        }
    },
    {
        tableName: "inspections",
        underscored: true,
        timestamps: true
    }
   );

   Inspection.associate = (models) => {
    Inspection.belongsTo(models.User, {
        foreignKey: "inspector_id",
        as: "inspector"
    });
   }
   return Inspection;
}
'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
     await queryInterface.createTable("inspections", {
       id: {
        type: Sequelize.BIGINT,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true
      },
      product_name: {
        type: Sequelize.STRING(100),
        allowNull: false
       },
       inspection_date: {
        type: Sequelize.DATE,
        allowNull: false
       },
       inspector_id: {
        type: Sequelize.BIGINT,
        allowNull: false
       },
       status: {
         type: Sequelize.SMALLINT,
         allowNull: false,
         validate: {
          isIn : [1,2,3,4]
         },
         comment: '1-Passed, 2-Failed, 3-Scheduled, 4-In Progress',
        },
       created_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP")
      }, 
       updated_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP")
       }
     })
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('inspections');
  }
};

require("dotenv").config()
const app = require("./src/app.js")

const port = process.env.PORT || 5001

app.listen(port, (req, res) => {
    console.log(`Server running on the port ${port}`)
})
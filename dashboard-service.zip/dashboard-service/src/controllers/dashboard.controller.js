const User = require("../../models/user.js")
const Inspection = require("../../models/inspection.js")
const Defect = require("../../models/defects.js");
const logger = require("../utils/logger.js")

const dashboardSummary = async (req, res) => {
 
 try{
    const totalInspections = await Inspection.count();
    const completedInspections = await Inspection.count({where: {status: 3}});
    const pendingInspections = await Inspection.count({where: {status: 1}});
    const failedInspections = await Inspection.count({where: {status: 2}});
    const criticalDefects = await Defect.count({where: {severity: 4}});
    const totalDefects = await Defect.count();

    return res.status(200).json({
        success: true,
        message: "Data retrived Successfully",
        data: {
           totalInspections ,
           totalDefects,
           completedInspections,
           pendingInspections,
           failedInspections,
           criticalDefects,
     }
    })

 }  catch(e)  {
    logger.error(`Dashboard error: ${e.message}`)
    return res.status(500).json({
        message: "Internal Server Error",
        success: false
    })
 }
}

const inspectionStatics = async (req, res) => {
    try {
  const failedInspections = await Inspection.count({where: {status: 2}});
  const inProgressInspections = await Inspection.count({where: {status: 4}});
  const passedInspections = await Inspection.count({where: {status: 1}});
  const schedulledInspections = await Inspection.count({where: {status: 3}});

  return res.status(200).json({
    success: true,
    message: "Inspection statistics retrieved successfully",
    data: {
      failedInspections,
      inProgressInspections,
      passedInspections,
      schedulledInspections
    }
  });
}catch (e) {
    logger.error(`Dashboard Error: ${e.message}`)
  return res.status(500).json({
    message: "Internal Server Error",
    success: false
  });
}
}

const defectStatics = async (req, res) => {
    try {
        const lowSeverityDefects = await Defect.count({ where: { severity: 1 } });
        const mediumSeverityDefects = await Defect.count({ where: { severity: 2 } });
        const highSeverityDefects = await Defect.count({ where: { severity: 3 } });
        const criticalSeverityDefects = await Defect.count({ where: { severity: 4 } });

        return res.status(200).json({
            success: true,
            message: "Defect statistics retrieved successfully",
            data: {
                lowSeverityDefects,
                mediumSeverityDefects,
                highSeverityDefects,
                criticalSeverityDefects
            }
        });
    } catch (e) {
        logger.error(`Dashboard Error: ${e.message}`)
        return res.status(500).json({
            message: "Internal Server Error",
            success: false
        });
    }
}

const compliancePercentage = async (req, res) => {
    try {
        const totalInspections = await Inspection.count();
        const completedInspections = await Inspection.count({ where: { status: 1 } });
        const compliance = totalInspections > 0 ? (completedInspections / totalInspections) * 100 : 0;

        return res.status(200).json({
            success: true,
            message: "Compliance percentage retrieved successfully",
            data: {
                compliance
            }
        });
    } catch (e) {
        logger.error(`Dashboard Error: ${e.message}`)
        return res.status(500).json({
            message: "Internal Server Error",
            success: false
        });
    }
}

module.exports = {
    dashboardSummary,
    inspectionStatics,
    defectStatics,
    compliancePercentage
}

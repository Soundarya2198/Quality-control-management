const express = require("express");
const router = express.Router();
const {dashboardSummary, inspectionStatics, defectStatics, compliancePercentage} = require("../controllers/dashboard.controller.js")
// const {verifyToken} = require("../middlewares/auth.midlleware.js")
// const {authorize} = require("../middlewares/authorize.middleware.js")
const ROLES = require("../../config/roles.js")

//router.get("/summary", verifyToken, authorize(ROLES.ADMIN, ROLES.MANAGER), dashboardSummary);
router.get("/summary", dashboardSummary);
router.get("/inspection-stats", inspectionStatics);
router.get("/defect-stats", defectStatics);
router.get("/compliance-percentage", compliancePercentage);
module.exports = router;
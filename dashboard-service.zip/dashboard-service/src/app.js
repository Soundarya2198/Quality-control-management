const express = require("express")
const app = express()
const dashboardRoute = require("./routes/dashboard.router.js")
const cors = require("cors")
const morgan = require("morgan")
const errorHandler = require("../src/middlewares/error.middleware.js")

app.use(cors());
app.use(express.json())
app.use(morgan("dev"))
app.use(errorHandler)
app.get("/", (req, res) => {
    res.send("Dashboard Service Running");
});
app.use("/api/dashboard", dashboardRoute)

module.exports = app;
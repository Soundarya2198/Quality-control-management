require("dotenv").config();
const app = require("./src/app.js")
const PORT = process.env.PORT || 5003

app.listen(PORT, () => {
  console.log(`Server running on the port ${PORT}`)
})
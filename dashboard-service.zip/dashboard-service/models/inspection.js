   const sequelize = require("../config/database.js");
   const {DataTypes} = require("sequelize")

   const Inspection = sequelize.define(
    "Inspection",
    {
        id: {
            type: DataTypes.BIGINT,
            primaryKey: true,
            autoIncrement: true
        },
        product_name:{
            type: DataTypes.STRING(100),
            allowNull: false
        },
        inspection_date:{
            type: DataTypes.DATE,
            allowNull: false
        },
        inspector_id: {
            type: DataTypes.BIGINT,
            allowNull: false
        },
        status: {
            type: DataTypes.SMALLINT,
            allowNull: false
        }
    },
    {
        tableName: "inspections",
        underscored: true,
        timestamps: true
    }
   )
module.exports = Inspection
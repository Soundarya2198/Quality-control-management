const sequelize = require("../config/database.js")
const {DataTypes} = require("sequelize")

const Defect = sequelize.define(
    "Defect",
   {
        id: {
         type: DataTypes.BIGINT,
         primaryKey: true,
         autoIncrement:true
       },
       inspection_id: {
          type: DataTypes.BIGINT,
          allowNull: false,
          references: {
            model: "inspections",
            key: "id"
          }
       },
       defect_type: {
          type: DataTypes.STRING(100),
          allowNull: false
       },
       severity: {
          type: DataTypes.SMALLINT,
          allowNull: false,
          comment: '1-Low, 2-Medium, 3-High, 4-Critical'
       },
       description: {
        type: DataTypes.TEXT,
        allowNull: true
       },
       status: {
        type: DataTypes.SMALLINT,
        allowNull: false,
        comment: '1-Open, 2-Inprogress, 3-Resolved'
       }
    },
    {
        tableName: 'defects',
        timestamps: true,
        underscored: true
    }
)

module.exports = Defect;
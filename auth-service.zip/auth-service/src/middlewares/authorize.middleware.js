const authorize = (...allowedRoles) => {
    return (req, res, next) => {
        try{
         const userRole = req.user.role;
         console.log(req.user)
         if(!allowedRoles.includes(userRole)){
            return res.status(403).json({
                success: false,
                message: "Access denied"
            })
         }

         next()
        }catch(e){
            console.log(e)
            return res.status(500).json({
                success: false,
                message: "Internal server errror"
            })
        }
    }
}

module.exports = authorize;
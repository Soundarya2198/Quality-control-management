const jwt = require("jsonwebtoken")

const verifyToken = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if(!authHeader){
        return res.status(401).json({
            success: false,
            message: "Token is required"
        })
    }

    const token = authHeader.split(" ")[1]

    try{
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();

    }catch(e){
        console.log(e)
        return res.status(500).json({
            success: false,
            meesgae: "Internal server error"
        })
    }
}

module.exports = verifyToken;
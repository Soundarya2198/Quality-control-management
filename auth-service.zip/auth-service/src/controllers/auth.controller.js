const bcrypt = require("bcryptjs")
const User = require("../models/user.model.js");
const jwt = require("jsonwebtoken");
const logger = require("../utils/logger.js")

const register = async(req, res) => {
    try{
        const {name, email, password, role } = req.body;
        if(!name || !email || !password || !role){
            return res.status(400).json({
                success: false,
                message: "All fields are required"
            })
        }

        const existingUser = await User.findOne({
            where : {email}
        });

        if(existingUser){
            logger.warn(`Email alredy exist ${email}`)
            return res.status(409).json({
                success : false,
                message: "Email already exist"
            })
        }

        const hashedPassword = await bcrypt.hash(password, 10)
        const user = await User.create({
            name,
            email,
            password : hashedPassword,
            role
        })
        logger.info(`User registered ${email}`)
        return res.status(201).json({
            success: true,
            message : "User created successfully",
            userId : user.id
        })
    }catch(e){
        logger.error(`Register Error: ${e.message}`)
        return res.status(500).json({
            success : false,
            message: "Internal server error"
        })
    }
   
}

const login = async (req, res) => {
    try{
   const {email, password} = req.body;
   console.log(email)
   console.log(password)
   if(!email || !password){
      return res.status(400).json({
        success : false,
        message: "Email and Password is required"
      })
   }

   const user = await User.findOne({
      where  : {email}
   })

   if(!user){
    logger.warn(`Invalid email ${email}`)
    return res.status(400).json({
    success : false,
    message: "Invalid email and password"
    })
   }

   const ispasswordMismatch = await bcrypt.compare(password, user.password)

   if(!ispasswordMismatch){
        logger.warn(`Invalid email & password ${email}`)
        return res.status(400).json({
        success : false,
        message: "Invalid email and password"
        })
   }
   const token = jwt.sign({id: user.id, email: user.email, role: user.role}, process.env.JWT_SECRET, {expiresIn: process.env.JWT_EXPIRES_IN})

   logger.info(`User Logged in ${user.email}`)

   return res.status(200).json({
        success : true,
        message: "User logged in sucessessfully",
        token,
        user
   })
}catch(e){
    logger.error(`Login error: ${e.message}`)
    return res.status(500).json({
        success: false,
        message : "Internal server error"
    })
}
}

const getUser = async (req, res) => {

   try{
        const {id} = req.params;
        const response = await User.findOne({
            where: {id}
        })
        logger.info(`User fetched ${response}`)
        return res.status(200).json({
            success : true,
            message: "User retrieved successfully",
            data: response
        })

   }catch(e){
        logger.error(`Error ${e.message}`)
        return res.status(500).json({
            success: false,
            message : "Internal server error"
        })
   }
}

const getUsers = async (req, res) => {

   try{
        const {role} = req.body
        const response = await User.findAll({
            where: {role}
        })
        return res.status(200).json({
            success : true,
            message: "Users retrieved successfully",
            data: response
        })

   }catch(e){
        logger.error(`Error ${e.message}`)
        return res.status(500).json({
            success: false,
            message : "Internal server error"
        })
   }
}

module.exports = {register, login, getUser, getUsers};
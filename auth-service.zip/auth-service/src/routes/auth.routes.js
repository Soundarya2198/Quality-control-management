const express = require("express")
const router = express.Router();
const {register, login, getUser, getUsers} = require("../controllers/auth.controller.js")
const verifyToken = require("../middlewares/auth.middleware.js")
const authorize = require("../middlewares/authorize.middleware.js")
const ROLES = require("../config/roles.js")

router.post("/register", register)
router.post("/login", login)
router.get("/get-user/:id", getUser)
router.post("/get-users", getUsers)


module.exports = router;
const {DataTypes, NOW} = require("sequelize")
const sequelize = require("../config/database.js")

const User = sequelize.define(
    "User",
    {
        id: {
            type: DataTypes.BIGINT,
            primaryKey: true,
            autoIncrement: true

        },
        name: {
            type: DataTypes.STRING(50),
            allowNull: false

        },
        email: {
            type: DataTypes.STRING(255),
            allowNull: false,
            unique: true

        }, 
        password: {
            type: DataTypes.STRING(255),
            allowNull: false
         },
        role: {
            type: DataTypes.SMALLINT,
            allowNull: false,
            validate: {
                isIn: [[1,2,3]]
            }

        },
        created_at: {
            type: DataTypes.DATE,
            defaultValue: NOW
        },
        updated_at: {
            type: DataTypes.DATE,
            defaultValue: NOW

        }
    },
    {
        tableName : "users",
        timestamps: false
    }
);

module.exports = User;
const express = require("express")
const authRoute = require("../src/routes/auth.routes.js")
const app = express()
const cors = require("cors")
const morgan = require("morgan")
const errorHandler = require("../src/middlewares/error.middleware.js")

app.use(cors())
app.use(express.json())
app.use(errorHandler)
app.use(morgan("dev"))

app.use("/api/auth", authRoute)

module.exports = app;

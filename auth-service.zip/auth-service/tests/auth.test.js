const request = require("supertest")
const app = require("../src/app.js")
const User = require("../src/models/user.model.js")
const bcrypt = require("bcryptjs");

jest.mock("../src/models/user.model.js")
jest.mock("bcryptjs")

describe("POST /api/auth/register", () => {
    afterEach(() => {
        jest.clearAllMocks()
    })

    test("Register Success", async() => {
       User.findOne.mockResolvedValue(null)
       User.create.mockResolvedValue({
        id: 1,
        name: "sound",
        email: "test@gmail.com",
        password: "123456",
        role: 1
       });

       const response = await request(app)
             .post("/api/auth/register")
             .send({
                name: "sound",
                email: "test@gmail.com",
                role: 1,
                password: "123456"
             });
        expect(response.statusCode).toBe(201)
        expect(response.body.success).toBe(true)
        expect(response.body.message).toBe("User created successfully")
        expect(response.body.userId).toBe(1)

    });

    test("Register Duplicate email", async () => {
        User.findOne.mockResolvedValue({
            id: 1,
            email: "sound@test.com"
        })

        const response = await request(app)
             .post("/api/auth/register")
             .send({
                name: "test",
                email: "sound@test.com",
                password: "123456",
                role: 1
             });
        expect(response.statusCode).toBe(409)
        expect(response.body.success).toBe(false)
        expect(response.body.message).toBe("Email already exist")
    })

    test("Register missing fields", async () => {
        const response = await request(app)
               .post("/api/auth/register")
               .send({
                name: "test",
                email: "test@gmail.com"
               })
        expect(response.statusCode).toBe(400)
        expect(response.body.success).toBe(false)
        expect(response.body.message).toBe("All fields are required")
    })

})

describe("POST /api/auth/login", () => {
    afterEach(() => {
        jest.clearAllMocks()
    })

    test("Login Success", async () => {
        User.findOne.mockResolvedValue({
            id: 1,
            name: "test",
            email: "test@gmail.com",
            password: "123456",
            role: 1
        })
        bcrypt.compare.mockResolvedValue(true)
        const response = await request(app)
              .post("/api/auth/login")
              .send({
                email: "test@gmail.com",
                password: "123456"
              })
        
        expect(response.statusCode).toBe(200)
        expect(response.body.success).toBe(true)
        expect(response.body.token).toBeDefined()
        expect(response.body.user).toBeDefined()
    });

    test("Login Invalid email", async () => {
        User.findOne.mockResolvedValue(null)
        const response = await request(app)
              .post("/api/auth/login")
              .send({
                email: "wrong@gmail.com",
                password: "123456"
              })
        expect(response.statusCode).toBe(400)
        expect(response.body.success).toBe(false)
        expect(response.body.message).toBe("Invalid email and password")
    })

    test("Login missing fields", async () => {
        const response = await request(app)
            .post("/api/auth/login")
            .send({
                email: "test@gmail.com"
            })
        expect(response.statusCode).toBe(400)
        expect(response.body.success).toBe(false)
        expect(response.body.message).toBe("Email and Password is required")
            
    })

    test("Login wrong password", async () => {
        User.findOne.mockResolvedValue({
            email: "sound@test.com",
            password: "123456"
        })
        bcrypt.compare.mockResolvedValue(false)
        const response = await request(app)
             .post("/api/auth/login")
             .send({
                email: "sound@test.com",
                password: "23423424"
             })

        expect(response.statusCode).toBe(400)
        expect(response.body.success).toBe(false)
        expect(response.body.message).toBe("Invalid email and password")
    })

    
})
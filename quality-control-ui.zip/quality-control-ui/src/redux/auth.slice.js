import { createSlice } from "@reduxjs/toolkit";

const authSlice = createSlice({
    name: "auth",
    initialState: {
        token: null,
        user: null
    },
    reducers: {
        loginSuccess: (state, actions) => {
        state.token = actions.payload.token,
        state.user = actions.payload.user
        },
        logout: (state) => {
         state.token= null,
         state.user = null
        }
    }
})

export const {loginSuccess, logout} = authSlice.actions;

export default authSlice.reducer
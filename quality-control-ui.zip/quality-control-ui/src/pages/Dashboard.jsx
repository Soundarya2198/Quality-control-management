import axios from "axios";
import { useCallback, useEffect, useState } from "react";
import DashboardCard from "../components/DashboardCard";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { ROLES } from "../config/roles.js";


function Dashboard(){
    const [error, setError] = useState("")
    const [loading, setLoading] = useState(false)
    const [summary, setSummary] = useState(null)
    const token = useSelector(state => state.auth.token) || localStorage.getItem("token")
    const [inspectionStats, setInspectionStats] = useState(null)
    const [defectStats, setDefectStats] = useState(null)
    const [compliance, setCompliance] = useState(0)
    const navigate = useNavigate();
    const user = useSelector(state => state.auth.user) || JSON.parse(localStorage.getItem("user")) || null    
    useEffect(() => {
      loadDashboard();
    }, [])

    const loadDashboard = async () => {
        setLoading(true)
        setError("")
        try{
           const headers = {
              Authorization: `Bearer ${token}`
           }
            const summaryResponse = await axios.get("http://localhost:5003/api/dashboard/summary",
            {headers});
            const inspectionResponse = await axios.get("http://localhost:5003/api/dashboard/inspection-stats", {headers})
            const defectResponse = await axios.get("http://localhost:5003/api/dashboard/defect-stats", {headers})
            const complianceResponse = await axios.get("http://localhost:5003/api/dashboard/compliance-percentage", {headers})


        setSummary(summaryResponse.data.data)
        setInspectionStats(inspectionResponse.data.data)
        setDefectStats(defectResponse.data.data)
        setCompliance(complianceResponse.data.data.compliance)

        }catch(e){
            console.log(e)
            if(e.response?.status === 401){
                navigate("/")
            }
             setError(
                e.response.data?.message ||
                "Failed to load dashboard"
            );
        }finally{
            setLoading(false)
        }
    }
    const refreshData = useCallback(() => {
        loadDashboard()
    }, []);
    
    return (
        <div className="container mt-4">

            {/* Heading */}
            <div className="d-flex justify-content-between align-items-center mb-4">

                <div>
                    <h2 className="mb-1">
                        Dashboard
                    </h2>

                    <p className="text-muted mb-0">
                        Overview of inspections and defects
                    </p>
                </div>

                <button
                    className="btn btn-outline-primary"
                    onClick={refreshData}
                    disabled={loading}
                >
                    {loading ? "Refreshing..." : "Refresh"}
                </button>

            </div>
            {error && (
            <div className="alert alert-danger alert-dismissible fade show">
                {error}

                <button
                    type="button"
                    className="btn-close"
                    onClick={() => setError("")}
                ></button>
            </div>
           )}
           {loading && (
        <div className="text-center my-4">

            <div
                className="spinner-border text-primary"
                role="status"
            >
                <span className="visually-hidden">
                    Loading...
                </span>
            </div>

            <p className="text-muted mt-2">
                Loading dashboard...
            </p>

        </div>
    )}


            {/* Section 1 - Summary */}
          { !loading &&  <>  <div className="row g-4 mb-5">

                <div className="col-md-3">
                    <DashboardCard
                        title="Total Inspections"
                        count={summary?.totalInspections || 0}
                    />
                </div>

                <div className="col-md-3">
                    <DashboardCard
                        title="Total Defects"
                        count={summary?.totalDefects || 0}
                    />
                </div>

                <div className="col-md-3">
                    <DashboardCard
                        title="Critical Defects"
                        count={summary?.criticalDefects || 0}
                    />
                </div>

                <div className="col-md-3">
                    <DashboardCard
                        title="Compliance %"
                        count={`${Number(compliance).toFixed(1)}%`}
                    />
                </div>

            </div>


            {/* Section 2 - Inspection Status */}
            { (user.role === ROLES.ADMIN || user.role === ROLES.MANAGER ) && 
            <div className="card shadow-sm border-0 mb-4">

                <div className="card-body">

                    <h5 className="mb-4">
                        Inspection Status
                    </h5>

                    <div className="row text-center">

                        <div className="col-md-3">
                            <h6 className="text-muted">
                                Scheduled
                            </h6>

                            <h3>
                                {inspectionStats?.schedulledInspections || 0}
                            </h3>
                        </div>


                        <div className="col-md-3">
                            <h6 className="text-muted">
                                In Progress
                            </h6>

                            <h3>
                                {inspectionStats?.inProgressInspections || 0}
                            </h3>
                        </div>


                        <div className="col-md-3">
                            <h6 className="text-muted">
                                Passed
                            </h6>

                            <h3>
                                {inspectionStats?.passedInspections || 0}
                            </h3>
                        </div>


                        <div className="col-md-3">
                            <h6 className="text-muted">
                                Failed
                            </h6>

                            <h3>
                                {inspectionStats?.failedInspections || 0}
                            </h3>
                        </div>

                    </div>

                </div>

            </div>
            }
            
            {/* Section 3 - Defect Severity */}
            {  (user.role === ROLES.ADMIN || user.role === ROLES.INSPECTOR ) &&
            <div className="card shadow-sm border-0 mb-4">

                <div className="card-body">

                    <h5 className="mb-4">
                        Defect Severity
                    </h5>

                    <div className="row text-center">

                        <div className="col-md-3">
                            <h6 className="text-muted">
                                Low
                            </h6>

                            <h3>
                                {defectStats?.lowSeverityDefects || 0}
                            </h3>
                        </div>


                        <div className="col-md-3">
                            <h6 className="text-muted">
                                Medium
                            </h6>

                            <h3>
                                {defectStats?.mediumSeverityDefects || 0}
                            </h3>
                        </div>


                        <div className="col-md-3">
                            <h6 className="text-muted">
                                High
                            </h6>

                            <h3>
                                {defectStats?.highSeverityDefects || 0}
                            </h3>
                        </div>


                        <div className="col-md-3">
                            <h6 className="text-muted">
                                Critical
                            </h6>

                            <h3>
                                {defectStats?.criticalSeverityDefects || 0}
                            </h3>
                        </div>

                    </div>

                </div>

            </div>
            }
            </>
          }
        </div>
    )
}
export default Dashboard;
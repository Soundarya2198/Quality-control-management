import { useEffect, useState } from "react";
import {INSPECTION_STATUS} from "../../config/inspection_status.js";
import axios from "axios";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import InspectionForm from "../../components/InspectionForm.jsx";

export default function CreateInspection(){
    const [formData, setFormData] = useState({
        product_name: "",
        inspection_date: "",
        inspector_id: "",
        status: ""
    })
    const [errors, setErrors] = useState({})


    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormData((prev) => ({
             ...prev,
             [name]: value
        }))
    }
    const token = useSelector(state => state.auth.token) || localStorage.getItem("token")
    const navigate = useNavigate()
    
    const validateForm = () => {
        const newErros = {};

        if(!formData.product_name.trim()){
            newErros.product_name = "Product name is required"
        }
        if(!formData.inspection_date){
            newErros.inspection_date = "Inspection Date is required"
        }
        if(!formData.inspector_id){
            newErros.inspector_id = "Select the Inspector"
        }
        if(!formData.status){
            newErros.status = "Select the State"
        }
        setErrors(newErros)
        return Object.keys(newErros).length === 0
    }

    const handleSubmit = async (e) => {
         e.preventDefault();
         if(!validateForm()){
            return false;
         }
        try{
            const response = await axios.post("http://localhost:5001/api/inspections/create", {
                ...formData
            },
            {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            navigate("/inspections", {
                state: {
                    successMessage: response.data.message
                }
            })

            }catch(e){
               console.log(e)
            }
         
    }
    
    return (
        <>
          <InspectionForm formData={formData} handleSubmit={handleSubmit} handleChange={handleChange} errors={errors} buttonName = "Create Inspection"/>
        </>

    );
}
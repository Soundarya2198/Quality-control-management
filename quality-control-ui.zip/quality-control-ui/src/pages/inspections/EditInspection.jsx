import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import InspectionForm from "../../components/InspectionForm";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export default function EditInspection() {
    const {id} = useParams();
    const navigate = useNavigate();
    const [errors, setErrors] = useState({})
    const token = useSelector(state => state.auth.token) || localStorage.getItem("token")

    const [formData, setFormData] = useState({
        product_name: "",
        inspection_date: "",
        inspector_id: "",
        status: ""
    })

    useEffect(() => {
       loadInspection()
    }, [])

    const handleSubmit = async (e) => {
      e.preventDefault();
      try{
        const response = await axios.put(`http://localhost:5001/api/inspections/update/${id}`, {
            ...formData
        }, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        })
        navigate("/inspections", {
            state: {
                successMessage: response.data.message
            }
        })
    }catch(e){
        console.log(e)
    }
    }

     
    const validateForm = () => {
        const newErros = {};

        if(!formData.product_name.trim()){
            newErros.product_name = "Product name is required"
        }
        if(!formData.inspection_date){
            newErros.inspection_date = "Inspection Date is required"
        }
        if(!formData.inspector_id){
            newErros.inspector_id = "Select the Inspector"
        }
        if(!formData.status){
            newErros.status = "Select the State"
        }
        setErrors(newErros)
        return Object.keys(newErros).length === 0
    }

    const handleChange = (e) => {
      const {name, value} = e.target;
      setFormData((prev) => (
        {
            ...prev,
            [name]: value
        }
      ))
    }

    const loadInspection = async () => {
        try{
        const response = await axios.get(`http://localhost:5001/api/inspections/${id}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        })
        const inspection = response.data.data
        setFormData({
            ...inspection,
            inspection_date: inspection.inspection_date?.split('T')[0]
        })
        
        }catch(e){
            console.log(e)
        }
    }

    return (
        <>
        <InspectionForm formData={formData} handleSubmit={handleSubmit} handleChange={handleChange} errors={errors} buttonName="Edit Inspection"/>
        </>
    );
}

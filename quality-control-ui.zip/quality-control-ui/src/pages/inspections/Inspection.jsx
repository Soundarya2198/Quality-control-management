import axios from "axios";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { INSPECTION_STATUS } from "../../config/inspection_status.js";
import { Link, useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";

export default function Inspection(){
    const[inspections, setInspections] = useState([])
    const token = useSelector(state => state.auth.token) || localStorage.getItem("token")
    const location = useLocation();
    const [successMessage, setSuccessMessage] = useState("")
    const [search, setSearch] = useState("")
    const [currentPage, setCurrentPage] = useState(1)
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState("")
    const navigate = useNavigate();

    useEffect(() => {
       if(successMessage){
         const timer = setTimeout(() => {
            setSuccessMessage("")
         }, 3000)
         return () => clearTimeout(timer)
       }
    }, [successMessage])

    useEffect(() => {
        if (location.state?.successMessage) {
            setSuccessMessage(
            location.state.successMessage
        );
        navigate(location.pathname, {
            replace: true
        });
    }
    }, []);

    useEffect(() => {
      loadInspections();
    }, [])
    useEffect(() => {
       setCurrentPage(1)
    }, [search])
    const itemsPerPage = 5;

    const loadInspections = async () => {
        setLoading(true)
        setError("")
      try{  
        const response = await axios.get("http://localhost:5001/api/inspections/", {
         headers: {
            Authorization: `Bearer ${token}`
         }
       })
       setInspections(response.data.data)
       }catch(e){
            console.log(e)
            if(e.response?.status === 401){
                navigate("/");
                return;
            }
            if(e.response?.status === 403){
                navigate("/access-denied")
            }
            setError(e.response?.data?.message || "Failed to load Inspections")
       }finally{
          setLoading(false)
       }
    }

    const filteredInspection = inspections.filter((ins) => {
        const searchText = search.toLowerCase()
        return (
           ins.product_name?.toLowerCase().includes(searchText) ||
           INSPECTION_STATUS[ins.status]?.toLowerCase().includes(searchText)
        )
    })

    const totalPages = Math.ceil(filteredInspection.length/itemsPerPage);
    const startIndex = (currentPage -1) * itemsPerPage;
    const currentInspections = filteredInspection.slice(startIndex, startIndex+itemsPerPage)

    const handleDelete = async (id) => {
        const confirmDelete = window.confirm("Are you sure you want to delete this inspection?")
        if(!confirmDelete){
            return;
        }
        try{
            const response = await axios.delete(`http://localhost:5001/api/inspections/delete/${id}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            })
            loadInspections()
            setSuccessMessage(response.data.message)
        }catch(e){
            console.log(e)
             if(e.response?.status === 401){
                navigate("/");
                return;
            }
            if(e.response?.status === 403){
                navigate("/access-denied")
            }
            setError(e.response?.data?.message || "Failed to delete Inspection")
        }
    }

    
    return (
     <>   
     <div className="d-flex justify-content-between mb-4">
        <input type="text" name="search" className="form-control" placeholder="Search by product name or status" onChange={(e) => setSearch(e.target.value)} value={search} style={{width:"300px"}}/>
        <Link to="/create-inspection" className="btn btn-primary">Create Inspection</Link>
    </div>
    {
        successMessage && (
            <div className="alert alert-success alert-dismissible fade show">
                {successMessage}
            <button type="button" className="btn-close" onClick={() => setSuccessMessage("")} />
            </div>
        )
    }
    {
        error && (
           <div className="alert alert-danger">
              {error}
           </div>
        )
    }
    {
        loading && (
            <div className="text-center my-3">
                <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">
                        Loading...
                    </span>
                </div>
            </div>
        )
    }
 {!loading && (
    <table className="table table-bordered">

        <thead>
            <tr>
                <th>Product Name</th>
                <th>Inspection Date</th>
                <th>Inspector Id</th>
                <th>Inspection Status</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>
        {currentInspections.length > 0 ? (
            currentInspections.map((ins) => (
                <tr key={ins.id}>
                    <td> {ins.product_name} </td>
                    <td>{new Date(ins.inspection_date).toLocaleDateString("en-IN", {
                                day: "2-digit",
                                month: "short",
                                year: "numeric"
                            })}
                    </td>
                    <td>{ins.inspector?.name}</td>
                    <td>{INSPECTION_STATUS[ins.status]}</td>
                    <td>
                        <div className="d-flex gap-2">
                            <Link to={`/edit-inspection/${ins.id}`} className="btn btn-sm btn-outline-primary"> Edit
                            </Link>
                            <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(ins.id)}>Delete
                            </button>
                        </div>
                    </td>

                </tr>
            ))
        ) : (
        <tr>
            <td colSpan="5" className="text-center">
                No inspections found
            </td>
        </tr>
        )}
        </tbody>
        </table>
    )}
   <div className="d-flex justify-content-center mt-4">
        <button className="btn btn-primary-outline me-2" disabled={currentPage ===1} onClick={() => setCurrentPage(currentPage -1)}>Previous</button>
        <span className="align-self-center">
            Page {currentPage} of {totalPages}
        </span>
        <button className="btn btn-primary-outline ms-2" disabled={currentPage === totalPages} onClick={() => setCurrentPage(currentPage+1)}>Next</button>

    </div>
    </>
    )

}
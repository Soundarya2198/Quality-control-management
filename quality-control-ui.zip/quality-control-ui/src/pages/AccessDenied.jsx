import { Link } from "react-router-dom";

export default function AccessDenied(){
    return (
        <div className="container text-center mt-5">
            <h1 className="display-1 text-danger">
                403
            </h1>
            <h3>
                Access Denied
            </h3>
            <p className="text-muted">
                You don't have permission to access this page
            </p>
            <Link to="/dashboard" className="btn btn-primary">Back to Dashboard</Link>
        </div>
    )
}
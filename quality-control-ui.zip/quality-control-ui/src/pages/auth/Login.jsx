import { useState } from "react";
import { loginUser } from "../../services/auth.service.js";
import { useNavigate, Link } from "react-router-dom";
import { loginSuccess } from "../../redux/auth.slice.js";
import { useDispatch } from "react-redux";

function Login() {
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [errors, setErrors] = useState({});

    const validateForm = () => {
        const newErrors = {};

        if (!email) {
            newErrors.email = "Email is required";
        } else if (!/\S+@\S+\.\S+/.test(email)) {
            newErrors.email = "Please enter a valid email";
        }

        if (!password) {
            newErrors.password = "Password is required";
        }

        setErrors(newErrors);

        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!validateForm()) {
            return;
        }

        try {
            const response = await loginUser({
                email,
                password,
            });
            console.log(response)
            dispatch(
                loginSuccess({
                    token: response.data.token,
                    user: response.data.user,
                })
            );

            localStorage.setItem("token", response.data.token);

            localStorage.setItem("user", JSON.stringify(response.data.user));

            navigate("/dashboard");
        } catch (error) {
            console.log(error);

            setErrors({
                email: error.response?.data.message
            })
        }
    };

    const handleChange = (e) => {
        const {name, value} = e.target;
        if(name === "email"){
            setEmail(value)
        }
        if(name === "password"){
            setPassword(value)
        }
        setErrors({})
    }

    return (
        <div
            className="container-fluid vh-100"
            style={{
                background: "linear-gradient(135deg, #e3f2fd, #bbdefb)",
            }}
        >
            <div className="row h-100">
                <div className="col-md-6 d-flex flex-column justify-content-center px-5">
                    <h1 className="display-3 fw-bold text-primary">Quality Control Management</h1>

                    <p className="lead text-secondary mt-3">
                        Manage inspections, monitor product quality, track defects and ensure compliance across the
                        organization.
                    </p>

                </div>

                <div className="col-md-6 d-flex justify-content-center align-items-center">
                    <div
                        className="card shadow-lg border-0 rounded-4"
                        style={{
                            width: "450px",
                        }}
                    >
                        <div className="card-body p-5">
                            <h2 className="text-center mb-4 fw-bold">Login</h2>

                            <form onSubmit={handleSubmit}>
                                <div className="mb-3">
                                    <label className="form-label">Email Address</label>

                                    <input
                                        type="email" name="email"
                                        className={`form-control ${errors.email ? "is-invalid" : ""}`}
                                        placeholder="Enter Email"
                                        value={email}
                                        onChange={handleChange}
                                    />

                                    {errors.email && <div className="invalid-feedback">{errors.email}</div>}
                                </div>

                                <div className="mb-4">
                                    <label className="form-label">Password</label>

                                    <input
                                        type="password" name="password"
                                        className={`form-control ${errors.password ? "is-invalid" : ""}`}
                                        placeholder="Enter Password"
                                        value={password}
                                        onChange={handleChange}
                                    />

                                    {errors.password && <div className="invalid-feedback">{errors.password}</div>}
                                </div>

                                <button type="submit" className="btn btn-primary w-100">
                                    Login
                                </button>
                            </form>

                            <hr className="my-4" />

                            <div className="text-center">
                                <p className="text-muted">Don't have an account?</p>

                                <Link to="/register" className="btn btn-outline-success">
                                    Sign Up
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Login;

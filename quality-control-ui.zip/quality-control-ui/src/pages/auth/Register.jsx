import { use, useState } from "react";
import { Link } from "react-router-dom";
import { ROLES } from "../../config/roles";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Register(){
    const navigate = useNavigate();
    const [errors, setErrors] = useState({})
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        password: "",
        role: ""
    });

    const handleChange = (e) => {
     const {name, value} = e.target;
      setFormData(prev => ({
        ...prev,
        [name]: value
      }))
    }

    const handleSubmit = async (e) => {
       e.preventDefault()
       if(!validForm()){
        return false;
       }
       try{
        const response = await axios.post("http://localhost:5000/api/auth/register", {
            ...formData
        })

        alert(response.data.message)
        navigate("/")

       }catch(e){

       }
    }

    const validForm = () => {
        const newErrors = {}
        if(!formData.name){
            newErrors.name = "Name is required"
        }
        if(!formData.email){
            newErrors.email = "Email is required"
        }
        if(!formData.password){
            newErrors.password = "Password is required"
        }
        if(!formData.role){
            newErrors.role= "Role is required"
        }
        setErrors(newErrors)
        return Object.keys(newErrors).length === 0;
    }

    return (
        <div
            className="container-fluid vh-100"
            style={{
                background: "linear-gradient(135deg, #e3f2fd, #bbdefb)",
            }}
        >
            <div className="row h-100">
                <div className="col-md-6 d-flex flex-column justify-content-center px-5">
                    <h1 className="display-3 fw-bold text-primary">Quality Control Management</h1>

                    <p className="lead text-secondary mt-3">
                        Manage inspections, monitor product quality, track defects and ensure compliance across the
                        organization.
                    </p>

                </div>

                <div className="col-md-6 d-flex justify-content-center align-items-center">
                    <div
                        className="card shadow-lg border-0 rounded-4"
                        style={{
                            width: "450px",
                        }}
                    >
                        <div className="card-body p-4">
                            <h2 className="text-center mb-4 fw-bold">Register</h2>

                            <form onSubmit={handleSubmit}>
                                <div className="mb-3">
                                    <label className="form-label">Name</label>

                                    <input
                                        type="text" name="name"
                                        className={`form-control ${errors.name ? "is-invalid" : ""}`}
                                        placeholder="Enter name"
                                        value={formData.name}
                                        onChange={handleChange}
                                    />

                                    {errors.name && <div className="invalid-feedback">{errors.name}</div>}
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Email Address</label>

                                    <input
                                        type="email" name="email"
                                        className={`form-control ${errors.email ? "is-invalid" : ""}`}
                                        placeholder="Enter Email"
                                        value={formData.email}
                                        onChange={handleChange}
                                    />

                                    {errors.email && <div className="invalid-feedback">{errors.email}</div>}
                                </div>

                                <div className="mb-4">
                                    <label className="form-label">Password</label>

                                    <input
                                        type="password" name="password"
                                        className={`form-control ${errors.password ? "is-invalid" : ""}`}
                                        placeholder="Enter Password"
                                        value={formData.password}
                                        onChange={handleChange}
                                    />

                                    {errors.password && <div className="invalid-feedback">{errors.password}</div>}
                                </div>

                                <div className="mb-3">
                                    <label className="form-label">Role</label>
                                     <select name="role" onChange={handleChange} className={`form-select ${errors.role ? "is-invalid" : ""}`}>
                                        <option value="">Select Role</option>
                                        {
                                            Object.keys(ROLES).map((role) => {
                                                return (
                                                    <option key={role} value={ROLES[role]}>{role}</option>
                                                )
                                            })
                                        }
                                     </select>
                                    
                                    {errors.role && <div className="invalid-feedback">{errors.role}</div>}
                                </div>

                                <button type="submit" className="btn btn-primary w-100">
                                    Register
                                </button>
                            </form>

                            <hr className="my-4" />

                            <div className="text-center">

                                <Link to="/" className="btn btn-outline-success">
                                    Login
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
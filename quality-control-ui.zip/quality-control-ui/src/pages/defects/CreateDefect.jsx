import { useEffect, useState } from "react";
import axios from "axios";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import DefectForm from "../../components/DefectForm";

export default function CreateDefect(){
    const [formData, setFormData] = useState({
        inspection_id: "",
        defect_type: "",
        severity: "",
        description: "",
        status: ""
    })
    const [errors, setErrors] = useState({})


    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormData((prev) => ({
             ...prev,
             [name]: value
        }))
    }
    const token = useSelector(state => state.auth.token) || localStorage.getItem("token")
    const navigate = useNavigate()
    
    const validateForm = () => {
        const newErros = {};
        if(!formData.inspection_id){
            newErros.inspection_id = "Inspection is required"
        }
        if(!formData.defect_type){
            newErros.defect_type = "Defect Type is required"
        }
        if(!formData.severity){
            newErros.severity = "Severity is required"
        }
        if(!formData.status){
            newErros.status = "Status is required"
        }
        if(!formData.description){
            newErros.description = "Description is required"
        }
        setErrors(newErros)
        return Object.keys(newErros).length === 0;
    }

    const handleSubmit = async (e) => {
         e.preventDefault();
         if(!validateForm()){
            return false;
         }
        try{
            const response = await axios.post("http://localhost:5002/api/defects/create", {
                ...formData
            },
            {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            navigate("/defects", {
                state: {
                    successMessage: response.data.message
                }
            })

            }catch(e){
               console.log(e)
            }
         
    }
    
    return (
        <>
          <DefectForm formData={formData} handleSubmit={handleSubmit} handleChange={handleChange} errors={errors} buttonName = "Create defect" token={token}/>
        </>

    );
}
import axios from "axios";
import { useEffect, useState } from "react"
import { useSelector } from "react-redux";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { DEFECT_STATUS } from "../../config/defect_status";
import { DEFECT_SEVERITY } from "../../config/defect_severity";

export default function Defects(){
    const [defects, setDefects] = useState([]);
    const location = useLocation()
    const [successMessage, setSuccessMessage] = useState("")
    const [search, setSearch] = useState("")
    const [currentPage, setCurrentPage] = useState(1)
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState("")
    const token = useSelector(state => state.auth.token) || localStorage.getItem("token")
    const navigate = useNavigate();

    useEffect(() => {
       loadDefects()
    }, [])

    useEffect(() => {
       if(successMessage){
         const timer = setTimeout(() => {
            setSuccessMessage("")
         }, 3000)
         return () => clearTimeout(timer)
       }
    }, [successMessage])

    useEffect(() => {
        if (location.state?.successMessage) {
            setSuccessMessage(
            location.state.successMessage
        );
        navigate(location.pathname, {
            replace: true
        });
    }
    }, []);
    useEffect(() => {
     setCurrentPage(1)
    }, [search])
    const itemsPerPage = 5;

    const loadDefects = async () => {
        setLoading(true)
        setError("")
        try{
           const response = await axios.get("http://localhost:5002/api/defects", {
            headers: {
                Authorization: `Bearer ${token}`
            }
           })
           setDefects(response.data.data)
        }catch(e){
            console.log(e)
             if(e.response?.status === 401){
                navigate("/");
                return;
            }
            if(e.response?.status === 403){
                navigate("/access-denied")
            }
            setError(e.response?.data?.message || "Failed to load Defects")
        }finally{
            setLoading(false)
        }
    }

    const filteredDefects = defects.filter((def) => {
        const searchText = search.toLowerCase();
        return (
            def.inspection.product_name?.toLowerCase().includes(searchText) ||
            def.defect_type?.toLowerCase().includes(searchText) ||
            DEFECT_SEVERITY[def.severity]?.toLowerCase().includes(searchText) ||
            DEFECT_STATUS[def.status]?.toLowerCase().includes(searchText)
        )
    })

    const totalPages = Math.ceil(filteredDefects.length/itemsPerPage)
    const startIndex = (currentPage -1) * itemsPerPage
    const currentDefects = filteredDefects.slice(startIndex, startIndex+itemsPerPage)

    const handleDelete = async(id) => {
       const confirmDelete = window.confirm("Are you sure you want to delete defect?")
       if(!confirmDelete){
        return;
       }
       try{
          const response = await axios.delete(`http://localhost:5002/api/defects/delete/${id}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
          })
          loadDefects();
          setSuccessMessage(response.data.message)
          
       }catch(e){
           console.log(e)
            if(e.response?.status === 401){
                navigate("/");
                return;
            }
            if(e.response?.status === 403){
                navigate("/access-denied")
            }
            setError(e.response?.data?.message || "Failed to delete defects")
       }
    }


    return (
    <>   
        <div className="d-flex justify-content-between mb-4">
            <input type="text" name = "search" className="form-control" placeholder="Search by Inspection or Defect type or Severity or Status" onChange={(e) => setSearch(e.target.value)} style={{width: "500px"}}/>
            <Link to="/create-defects" className="btn btn-primary">Create Defects</Link>
        </div>
        {
            successMessage && (
                <div className="alert alert-success alert-dismissible fade show">
                    {successMessage}
                <button type="button" className="btn-close" onClick={() => setSuccessMessage("")} />
                </div>
            )
        }{
            error && (
                <div className="alert alert-danger">
                    {error}
                </div>
            )
        }
        {
            loading && (
            <div className="text-center my-3">
                <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">
                        Loading...
                    </span>
                </div>
            </div>
            )
        }
        { 
        !loading  && 
        <table className="table table-bordered">
            <thead>
                <tr>
                <th>Inspection For</th>
                <th>Defect Type</th>
                <th>Severity</th>
                <th>Description</th>
                <th>Status</th>
                <th>Action</th>
                </tr>
            </thead>
            <tbody>
                { currentDefects.length > 0 ? (
                    currentDefects.map((defect)=> {
                        return (
                        <tr key={defect.id}>
                            <td>{defect.inspection?.product_name}</td>
                            <td>{defect.defect_type}</td>
                            <td>{DEFECT_SEVERITY[defect.severity]}</td>
                            <td>{defect.description}</td>
                            <td>{DEFECT_STATUS[defect.status]}</td>
                            <td>
                                <div className="d-flex gap-2">
                                    <Link to={`/edit-defects/${defect.id}`} className="btn btn-sm btn-outline-primary">Edit </Link>
                                    <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(defect.id)}> Delete</button>
                                </div>
                            </td>
                        </tr>
                        
                    )}) ) : (
                        <tr>
                            <td colSpan="5" className="text-center">
                                No inspections found
                            </td>
                        </tr>
                    )
                }
            </tbody>

        </table>
}
        <div className="d-flex justify-content-center mt-4">
            <button className="btn btn-primary-outline me-2" disabled={currentPage ===1} onClick={() => setCurrentPage(currentPage -1)}>Previous</button>
            <span className="align-self-center">
                Page {currentPage} of {totalPages}
            </span>
            <button className="btn btn-primary-outline ms-2" disabled={currentPage === totalPages} onClick={() => setCurrentPage(currentPage+1)}>Next</button>
        </div>
    </>
)
}
import { useEffect, useState } from "react"
import DefectForm from "../../components/DefectForm"
import { useSelector } from "react-redux"
import { useNavigate, useParams } from "react-router-dom"
import axios from "axios"

export default function EditDefect(){
    const [formData, setFormData] = useState([])
    const token = useSelector(state => state.auth.token) || localStorage.getItem("token")
    const [errors, setErrors] = useState({})
    const {id} = useParams();
    const navigate = useNavigate()
    useEffect(() => {
      loadInspection()
    }, [])
    
    const loadInspection = async () => {
        try{
            const response = await axios.get(`http://localhost:5002/api/defects/${id}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            })
            const defect = response.data.data
            setFormData({
                ...defect
            })

        }catch(e){
            console.log(e)
        }
    }
    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }))
    }
    const validateForm = () => {
        const newErros = {};
        if(!formData.inspection_id){
            newErros.inspection_id = "Inspection is required"
        }
        if(!formData.defect_type){
            newErros.defect_type = "Defect Type is required"
        }
        if(!formData.severity){
            newErros.severity = "Severity is required"
        }
        if(!formData.status){
            newErros.status = "Status is required"
        }
        if(!formData.description){
            newErros.description = "Description is required"
        }
        setErrors(newErros)
        return Object.keys(newErros).length === 0;
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        if(!validateForm()){
            return false;
        }
        try{
          const response = await axios.put(`http://localhost:5002/api/defects/update/${id}`, {
            ...formData
          }, {
            headers: {
                Authorization: `Bearer ${token}`
            }
          })
          navigate("/defects", {
            state: {
                successMessage: response.data.message
            }
          })
        }catch(e){
            console.log(e)
        }
    }

    return(
        <DefectForm formData={formData} handleChange={handleChange} handleSubmit={handleSubmit} errors={errors} buttonName="Edit Defects" token={token}/>
    )
}
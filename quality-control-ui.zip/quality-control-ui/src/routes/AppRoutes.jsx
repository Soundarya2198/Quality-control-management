import { Route, Routes } from "react-router-dom";
import Login from "../pages/auth/Login.jsx";
import Dashboard from "../pages/Dashboard.jsx";
import ProtectedRoute from "../components/ProtectedRoute.jsx";
import Layout from "../components/Layout.jsx";
import Inspection from "../pages/inspections/Inspection.jsx";
import CreateInspection from "../pages/inspections/CreateInspection.jsx";
import EditInspection from "../pages/inspections/EditInspection.jsx";
import Register from "../pages/auth/Register.jsx";
import Defects from "../pages/defects/Defects.jsx";
import CreateDefect from "../pages/defects/CreateDefect.jsx";
import EditDefect from "../pages/defects/EditDefect.jsx";
import AccessDenied from "../pages/AccessDenied.jsx";
import RoleProtectedRoute from "../components/RoleProtectedRoute.jsx";
import { ROLES } from "../config/roles.js";

function AppRoutes() {
    return (
    <Routes>
        {/* Login without navbar */}
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register/>} />
        <Route path="/access-denied" element={<AccessDenied/>} />
        {/* All protected pages inside Layout */}
        <Route element={<ProtectedRoute> <Layout /> </ProtectedRoute>} >
           <Route path="/dashboard" element={<Dashboard />} />
           
           {/* Role access for inspection module admin, manager */}
           <Route path="/inspections" element={ 
             <RoleProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.MANAGER]}><Inspection/></RoleProtectedRoute>
            } />
           <Route path="/create-inspection" element={
            <RoleProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.MANAGER]}>
            <CreateInspection/>
            </RoleProtectedRoute>
            } />
           <Route path="/edit-inspection/:id" element={
            <RoleProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.MANAGER]}>
            <EditInspection/>
            </RoleProtectedRoute>
            } />

            {/* Role access for inspection module admin, inspector */}

            <Route path="/create-defects" element={
                <RoleProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.INSPECTOR]}>
                <CreateDefect/>
                </RoleProtectedRoute>
            } />
           <Route path="/edit-defects/:id" element ={
            <RoleProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.INSPECTOR]}>
            <EditDefect/>
            </RoleProtectedRoute>
            } />
           <Route path="/defects" element={
            <RoleProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.INSPECTOR]}>
            <Defects/>
            </RoleProtectedRoute>
            } />

        </Route>

    </Routes>

    );
}

export default AppRoutes;
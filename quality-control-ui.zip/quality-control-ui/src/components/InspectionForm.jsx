import { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import {INSPECTION_STATUS} from "../config/inspection_status.js";
import axios from "axios";
import { ROLES } from "../config/roles.js";
import { Link } from "react-router-dom";


export default function InspectionForm({formData, handleSubmit, handleChange, errors, buttonName}){
   
    const [inspectors, setInspectors] = useState([]);
    const token = useSelector(state => state.auth.token) || localStorage.getItem("token")

    useEffect(() => {
       loadInspectors()
    }, [])

    
 
    const loadInspectors = async () => {
       try{
        const response = await axios.post("http://localhost:5000/api/auth/get-users/", 
            { role: ROLES.INSPECTOR}, 
            {
             headers: {
                Authorization : `Bearer ${token}`
             }
        })
        setInspectors(response.data.data)

       }catch(e){
          console.log(e)
       }
    }

   

    return (
    <div className="container mt-4">
        <div className="row justify-content-center">
            <div className="col-md-8">
                <div className="card shawdow border-0">
                    <div className="card-header bg-primary text-white">
                        <h3 className="mb-0">{buttonName}</h3>
                    </div>
                    <div className="card-body">
                        <form onSubmit={handleSubmit}>
                            <div className="mb-3">
                                <label className="form-label">Product Name</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Enter the product name"
                                    value={formData.product_name}
                                    name="product_name"
                                    onChange={handleChange}
                                />
                                {errors.product_name && <small className="text-danger">{errors.product_name}</small>}
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Inspection Date</label>
                                <input
                                    type="date"
                                    className="form-control"
                                    value={formData.inspection_date}
                                    name="inspection_date"
                                    onChange={handleChange}
                                />
                                {errors.inspection_date && (
                                    <small className="text-danger">{errors.inspection_date}</small>
                                )}
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Inspector</label>
                                <select
                                    className="form-select"
                                    value={formData.inspector_id}
                                    name="inspector_id"
                                    onChange={handleChange}
                                >
                                    <option value="">Select Inspector</option>
                                    {inspectors.map((inspector) => {
                                        return (
                                            <option key={inspector.id} value={inspector.id}>
                                                {inspector.name}
                                            </option>
                                        );
                                    })}
                                </select>
                                {errors.inspector_id && <small className="text-danger">{errors.inspector_id}</small>}
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Status</label>
                                <select
                                    className="form-select"
                                    value={formData.status}
                                    name="status"
                                    onChange={handleChange}
                                >
                                    <option value="">Select status</option>
                                    {Object.entries(INSPECTION_STATUS).map(([key, value]) => {
                                        return (
                                            <option key={key} value={key}>
                                                {value}
                                            </option>
                                        );
                                    })}
                                </select>
                                {errors.status && <small className="text-danger">{errors.status}</small>}
                            </div>
                            <div className="d-flex justify-content-end gap-2">
                                <Link to="/inspections" className="btn btn-secondary">
                                    Back
                                </Link>
                                <button type="submit" className="btn btn-success">
                                    {buttonName}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
);

}
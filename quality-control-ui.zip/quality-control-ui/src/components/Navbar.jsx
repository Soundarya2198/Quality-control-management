import { useSelector, useDispatch } from "react-redux"
import { Link, useNavigate } from "react-router-dom"
import {logout} from "../redux/auth.slice.js"
import {ROLES} from "../config/roles.js"

export default function Navbar(){
    const user = useSelector(state => state.auth.user) || JSON.parse(localStorage.getItem("user")) || null
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const handleClick = () => {
        dispatch(logout())
        navigate("/")
    }

    return(
        <nav className="navbar bg-dark navbar-dark">
            <div className="container">
              <Link to="/dashboard" className="navbar-brand">Quality Control Management</Link>
              <div className="d-flex align-items-center gap-3">
                <Link to="/dashboard" className="text-white text-decoration-none">Dashboard</Link>
                { (user.role === ROLES.ADMIN || user.role === ROLES.MANAGER ) && 
                <Link to="/inspections" className="text-white text-decoration-none">Inspections</Link>
                 }
                 { (user.role === ROLES.ADMIN || user.role === ROLES.INSPECTOR ) &&
                <Link to="/defects" className="text-white text-decoration-none">Defects</Link> }
                <span className="text-white">
                    Welcome {user?.name}
                </span>
                <button className="btn btn-danger" onClick={handleClick}>Logout</button>

              </div>
            </div>
        </nav>
    )
}
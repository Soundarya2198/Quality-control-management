import axios from "axios";
import { useEffect, useState } from "react";
import {DEFECT_SEVERITY} from "../config/defect_severity.js"
import {DEFECT_STATUS} from "../config/defect_status.js"
import { Link } from "react-router-dom";

export default function DefectForm({formData, handleSubmit, handleChange, errors, buttonName, token}){
    const [inspections, setInspections] = useState([]);
    useEffect(() => {
      loadInspections()
    }, [])
    
    const loadInspections = async () => {
        try{
          const response = await axios.get("http://localhost:5001/api/inspections", {
            headers: {
                Authorization: `Bearer ${token}`
            }
          })
          setInspections(response.data.data)
        }catch(e){
            console.log(e)
        }
    }

       return (
        <div className="container mt-4">
            <div className="row justify-content-center">
                <div className="col-md-8">
                    <div className="card shawdow border-0">
                        <div className="card-header bg-primary text-white">
                            <h3 className="mb-0">{buttonName}</h3>
                        </div>
                        <div className="card-body">
                            <form onSubmit={handleSubmit}>
                                <div className="mb-3">
                                    <label className="form-label">Inspection</label>
                                    <select
                                        className="form-select"
                                        value={formData.inspection_id}
                                        name="inspection_id"
                                        onChange={handleChange}
                                    >
                                        <option value="">Select Inspection</option>
                                        {inspections.map((inspection) => {
                                            return (
                                                <option key={inspection.id} value={inspection.id}>
                                                    {inspection.product_name}
                                                </option>
                                            );
                                        })}
                                    </select>
                                    {errors.inspection_id && <small className="text-danger">{errors.inspection_id}</small>}
                                </div>
                                
                                <div className="mb-3">
                                    <label className="form-label">Defect Type</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        value={formData.defect_type}
                                        name="defect_type"
                                        onChange={handleChange}
                                    />
                                    {errors.defect_type && (
                                        <small className="text-danger">{errors.defect_type}</small>
                                    )}
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Severity</label>
                                    <select
                                        className="form-select"
                                        value={formData.severity}
                                        name="severity"
                                        onChange={handleChange}
                                    >
                                        <option value="">Select Severity</option>
                                        {
                                            Object.entries(DEFECT_SEVERITY).map(([key, value]) => {
                                                return (
                                                    <option key={key} value={key}>{value}</option>
                                                )
                                            })
                                        }
                                        
                                    </select>
                                    {errors.severity && <small className="text-danger">{errors.severity}</small>}
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Status</label>
                                    <select
                                        className="form-select"
                                        value={formData.status}
                                        name="status"
                                        onChange={handleChange}
                                    >
                                        <option value="">Select status</option>
                                        {Object.entries(DEFECT_STATUS).map(([key, value]) => {
                                            return (
                                                <option key={key} value={key}>
                                                    {value}
                                                </option>
                                            );
                                        })}
                                    </select>
                                    {errors.status && <small className="text-danger">{errors.status}</small>}
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Description</label>
                                    <textarea className="form-control" name="description" value={formData.description} onChange={handleChange}/>
                                     {errors.description && <small className="text-danger">{errors.description}</small>}
                                </div>
                                <div className="d-flex justify-content-end gap-2">
                                    <Link to="/defects"  className="btn btn-secondary">
                                        Back
                                    </Link>
                                    <button type="submit" className="btn btn-success">
                                        {buttonName}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
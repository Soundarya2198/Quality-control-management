import { Navigate } from "react-router-dom"

export default function RoleProtectedRoute({children, allowedRoles}){
   const user = JSON.parse(localStorage.getItem("user"))
   if(!user){
     return <Navigate to="/" />
   }
   if(!allowedRoles.includes(user.role)){
      return (
        <Navigate to="/access-denied" replace />
      )
   }

   return children
}
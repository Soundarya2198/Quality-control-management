import React from "react"

const DashboardCard = React.memo(({title, count}) => {
  return (
     <div className="card shadow-sm border-0 h-100">
      <div className="card-body text-center">
        <h6 className="text-muted mb-3">
           {title}
        </h6>
        <h3 className="fw-bold mb-0">
           {count}
        </h3>
      </div>

     </div>
  )
})

export default DashboardCard;
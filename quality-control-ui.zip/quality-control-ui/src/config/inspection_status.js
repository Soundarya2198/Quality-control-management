export const INSPECTION_STATUS = {
        1: "Passed",
        2: "Failed",
        3: "Scheduled",
        4: "Inprogress"
}
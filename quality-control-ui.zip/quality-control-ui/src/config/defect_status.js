export const DEFECT_STATUS = {
    1: "Open",
    2: "InProgress",
    3: "Resolved"
}
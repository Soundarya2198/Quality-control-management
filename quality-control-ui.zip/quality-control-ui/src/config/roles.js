export const ROLES = {
    ADMIN : 1,
    INSPECTOR: 2,
    MANAGER: 3
}
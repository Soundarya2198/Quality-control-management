'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add altering commands here.
     *
     * Example:
     * await queryInterface.createTable('users', { id: Sequelize.INTEGER });
     */
    await queryInterface.createTable('defects', {
       id: {
         type: Sequelize.BIGINT,
         primaryKey: true,
         autoIncrement:true
       },
       inspection_id: {
          type: Sequelize.BIGINT,
          allowNull: false,
          references: {
            model: "inspections",
            key: "id"
          },
          onUpdate: 'CASCADE',
          onDelete: 'CASCADE'
       },
       defect_type: {
          type: Sequelize.STRING(100),
          allowNull: false
       },
       severity: {
          type: Sequelize.SMALLINT,
          allowNull: false,
          comment: '1-Low, 2-Medium, 3-High, 4-Critical'
       },
       description: {
        type: Sequelize.TEXT,
        allowNull: true
       },
       status: {
        type: Sequelize.SMALLINT,
        allowNull: false,
        comment: '1-Open, 2-Inprogress, 3-Resolved'
       },
       created_at:{
          type: Sequelize.DATE,
          allowNull: false,
          defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
       }, 
       updated_at: {
          type: Sequelize.DATE,
          allowNull: false,
          defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
       }
    }

    )
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
    await queryInterface.dropTable('defects');
  }
};

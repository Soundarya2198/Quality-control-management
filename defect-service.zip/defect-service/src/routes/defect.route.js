const express = require("express")
const router = express.Router()
const {createDefect, getAllDefects, getDefectById, updateDefect, deleteDefect} = require("../controllers/defect.controller.js")
const {verifyToken} = require("../middlewares/auth.middleware.js")
const {authorize} = require("../middlewares/authorize.middleware.js")
const ROLES = require("../../config/roles.js");

router.post("/create", verifyToken, authorize(ROLES.INSPECTOR, ROLES.ADMIN), createDefect)
router.get("/", verifyToken, authorize(ROLES.INSPECTOR, ROLES.ADMIN), getAllDefects)
router.get("/:id", verifyToken, authorize(ROLES.INSPECTOR, ROLES.ADMIN), getDefectById)
router.put("/update/:id", verifyToken, authorize(ROLES.INSPECTOR, ROLES.ADMIN), updateDefect)
router.delete("/delete/:id", verifyToken, authorize(ROLES.INSPECTOR, ROLES.ADMIN), deleteDefect)

module.exports = router;
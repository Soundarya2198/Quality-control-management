const express = require("express")
const app = express();
const defectRoutes = require("./routes/defect.route.js")
const cors = require("cors")
const errorHandler = require("../src/middlewares/error.middleware.js")
const morgan = require("morgan")

app.use(cors())
app.use(express.json());
app.use(errorHandler)
app.use(morgan("dev"))

app.use("/api/defects", defectRoutes)


module.exports = app;

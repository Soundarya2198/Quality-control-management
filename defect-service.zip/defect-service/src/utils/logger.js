const winston = require("winston")
const dailyRotateFile =  require("winston-daily-rotate-file")

const logger = winston.createLogger({
    level: "info",
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.printf(
            ({timestamp, level, message}) => `${timestamp} ${level} ${message}`
        )
    ),
    transports: [
        new winston.transports.Console(),
        new dailyRotateFile({
            dirname: "logs",
            filename: "defect-service-%DATE%.log",
            datePattern: "YYYY-MM-DD",
            maxFiles: "30d",
            maxSize: "20m"
        })
    ]
});

module.exports = logger;
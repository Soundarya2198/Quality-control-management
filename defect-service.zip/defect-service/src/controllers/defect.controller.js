const {Defect, Inspection} = require("../../models")
const logger = require("../utils/logger.js")

const createDefect = async(req, res) => {
    try{
    const {inspection_id, defect_type, severity, description, status } = req.body
    if(!inspection_id || !defect_type || !severity || !status){
        return res.status(400).json({
            success: false,
            message: "All fields are required"
        })
    }

    const defects = await Defect.create({
        inspection_id,
        defect_type,
        severity,
        description,
        status
    });
    logger.info(`Defects created ${defects}`)
    return res.status(201).json({
        success: true,
        message: "Defects created Sucessfully"
    })
}catch(e){
    logger.error(`Defect Error ${e.message}`)
    return res.status(500).json({
        success: false,
        message: "Internal Server error"
    })
}
}

const getAllDefects = async (req, res) => {
  try{
    const page = req.query.page || 1;
    const limit = req.query.limit || 10;
    const offset = (page-1)*limit ;
    
    const defects = await Defect.findAll({
        include: [
           {
            model: Inspection,
            as : "inspection",
            attribute: ["id", "product_name"]
           }
        ],
        limit,
        offset,
        order: [["created_at", "Desc"]]
    })
    return res.status(200).json({
        success: true,
        message: "Data retrieved successfully",
        data: defects
    })

  }catch(e){
       logger.error(`Get all defects: ${e.message}`)
       return res.status(500).json({
        success: false,
        message: "Internal Server Error",
    })
  }
}

const getDefectById = async (req, res) => {
    try{
    const {id} = req.params;
    const defect = await Defect.findOne({
        where: {
            id
        }
    })
    if(!defect){
        logger.warn(`Defect not found ${id}`)
        return res.status(404).json({
        success: false,
        message: "Defect not found",
      })
    }
    return res.status(200).json({
        success: true,
        message: "Data retrieved successfully",
        data: defect
    })
}catch(e){
    logger.error(`Error: ${e.message}`)
    return res.status(500).json({
        success: false,
        message: "Internal Server Error",
    })
}

}

const updateDefect = async (req, res) => {
try{
 const {id} = req.params;
 const {inspection_id, defect_type, severity, description, status } = req.body
    if(!inspection_id || !defect_type || !severity || !status){
        return res.status(400).json({
            success: false,
            message: "All fields are required"
        })
    }

    const defect = await Defect.findOne({
        where: {
            id
        }
    })
    if(!defect){
        logger.warn(`Defect not found ${id}`)
        return res.status(404).json({
        success: false,
        message: "Defect not found",
      })
    }

    const updateDefects = await defect.update({
        inspection_id,
        defect_type,
        severity,
        description,
        status
    });
    logger.info(`Defect updated ${id}`)
    return res.status(200).json({
        success: true,
        message: "Defects updated Sucessfully"
    })
}catch(e){
    logger.error(`Error: ${e.message}`)
    return res.status(500).json({
        success: false,
        message: "Internal Server Error",
    })
}
}

const deleteDefect = async (req, res) => {
   try{
   const {id} = req.params;
   const defect = await Defect.findOne({
        where: {
            id
        }
    })
    if(!defect){
        logger.warn(`Defect not found ${id}`)
        return res.status(404).json({
        success: false,
        message: "Defect not found",
      })
    }
    defect.destroy();
    logger.info(`Defect deleted ${id}`)
     return res.status(200).json({
        success: true,
        message: "Defects deleted Sucessfully"
    })
}catch(e){
   logger.error(`Error: ${e.message}`)
   return res.status(500).json({
        success: false,
        message: "Internal Server Error",
    })
}
}

module.exports = {
    createDefect,
    getAllDefects,
    getDefectById,
    updateDefect,
    deleteDefect
}
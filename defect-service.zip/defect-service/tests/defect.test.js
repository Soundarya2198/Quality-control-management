const request = require("supertest")
const app = require("../src/app.js")
const jwt = require("jsonwebtoken")
require("dotenv").config()

jest.mock("../models", () => ({
    Defect: {
      create: jest.fn(),
      findAll: jest.fn(),
      findOne: jest.fn()
    },
    Inspection: {}
}));

const {Defect} = require("../models")

describe("Post /api/defects/", () => {
    let token;
    afterEach(() => {
        jest.clearAllMocks()
    })

    beforeEach(() => {
         token = jwt.sign(
        {
            id: 1,
            email: "admin@test.com",
            role: 1
        },
        process.env.JWT_SECRET,
        {
            expiresIn: '1h'
        })
    })
    test("Create Defect", async () => {
       Defect.create.mockResolvedValue({
            id: 1,
            inspection_id: 1,
            defect_type: "test",
            severity: 2,
            description : "This is test",
            status: 2
       });
       const response = await request(app)
       .post("/api/defects/create")
       .set("Authorization", `Bearer ${token}`)
       .send({
            inspection_id: 1,
            defect_type: "test",
            severity: 2,
            description : "This is test",
            status: 2
       })

        expect(response.statusCode).toBe(201)
        expect(response.body.success).toBe(true)
        expect(response.body.message).toBe("Defects created Sucessfully")
        expect(Defect.create).toHaveBeenCalledTimes(1);

        expect(Defect.create).toHaveBeenCalledWith({
            inspection_id: 1,
            defect_type: "test",
            severity: 2,
            description : "This is test",
            status: 2
        });
    });

    test("Defect missing fields required", async () => {
        const response = await request(app)
            .post("/api/defects/create")
            .set("Authorization", `Bearer ${token}`)
            .send({
            product_name: ""
        })
        
        expect(response.statusCode).toBe(400)
        expect(response.body.success).toBe(false)
        expect(response.body.message).toBe("All fields are required")
    });
});

describe("GET /api/defects", () => {
    let token;
    afterEach(() => {
        jest.clearAllMocks()
    });

    beforeEach(() => {
         token = jwt.sign(
        {
            id: 1,
            email: "admin@test.com",
            role: 1
        },
        process.env.JWT_SECRET,
        {
            expiresIn: '1h'
        })
    });

    test("Gett all defects", async() => {
        Defect.findAll.mockResolvedValue([
            {
                id: 1,
                inspection_id: 1,
                defect_type: "test",
                severity: 2,
                description : "This is test",
                status: 2
            },
            {
                id: 2,
                inspection_id: 1,
                defect_type: "test2",
                severity: 3,
                description : "This is test2",
                status: 3
            }
        ]);

        const response = await request(app)
        .get("/api/defects")
        .set("Authorization", `Bearer ${token}`)

        expect(response.statusCode).toBe(200)
        expect(response.body.success).toBe(true)
        expect(response.body.message).toBe("Data retrieved successfully")
        expect(response.body.data).toBeDefined()
        expect(response.body.data).toHaveLength(2)
    })
});

describe("DELETE Sucess", () => {
     let token;
    afterEach(() => {
        jest.clearAllMocks()
    });

    beforeEach(() => {
         token = jwt.sign(
        {
            id: 1,
            email: "admin@test.com",
            role: 1
        },
        process.env.JWT_SECRET,
        {
            expiresIn: '1h'
        })
    });

    test("Delete Sucessfull", async () => {
        const mockDefect = {
            id: 1,
            destroy: jest.fn()
        }

        Defect.findOne.mockResolvedValue(mockDefect);
        mockDefect.destroy.mockResolvedValue()

        const response = await request(app)
        .delete("/api/defects/delete/1")
        .set("Authorization", `Bearer ${token}`)

        expect(response.statusCode).toBe(200)
        expect(response.body.success).toBe(true)
        expect(response.body.message).toBe("Defects deleted Sucessfully")
    })

    test("Delete id not found", async () => {
       
        Defect.findOne.mockResolvedValue(null)

        const response = await request(app)
        .delete("/api/defects/delete/2")
        .set("Authorization", `Bearer ${token}`)

        expect(response.statusCode).toBe(404)
        expect(response.body.success).toBe(false)
        expect(response.body.message).toBe("Defect not found")
    })
})